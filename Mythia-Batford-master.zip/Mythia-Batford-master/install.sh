pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
npm install
npm i hmtai
npm i booru
npm i image-to-pdf
npm i nhentai-node-api
npm i acrcloud
npm i sagiri
npm update
